import React, { useState, useCallback } from 'react';
import { Document, Page, pdfjs } from 'react-pdf';

// Set up PDF.js worker
pdfjs.GlobalWorkerOptions.workerSrc = `//unpkg.com/pdfjs-dist@${pdfjs.version}/build/pdf.worker.min.js`;

// Polyfill DOMMatrix for SSR compatibility
if (typeof window !== 'undefined' && !window.DOMMatrix) {
  window.DOMMatrix = require('dommatrix');
}

interface PDFViewerControlProps {
  pdfFile: File;
}

const PDFViewerControl: React.FC<PDFViewerControlProps> = ({ pdfFile }) => {
  const [numPages, setNumPages] = useState<number | null>(null);
  const [pageNumber, setPageNumber] = useState<number>(1);
  const [loading, setLoading] = useState<boolean>(true);
  const [error, setError] = useState<string | null>(null);
  const [inputPage, setInputPage] = useState<string>('1');

  const onDocumentLoadSuccess = useCallback(({ numPages }: { numPages: number }) => {
    setNumPages(numPages);
    setLoading(false);
    setError(null);
  }, []);

  const onDocumentLoadError = useCallback((error: Error) => {
    setError('Erreur lors du chargement du PDF');
    setLoading(false);
    console.error('PDF load error:', error);
  }, []);

  const handlePrevious = () => {
    if (pageNumber > 1) {
      setPageNumber(pageNumber - 1);
      setInputPage((pageNumber - 1).toString());
    }
  };

  const handleNext = () => {
    if (numPages && pageNumber < numPages) {
      setPageNumber(pageNumber + 1);
      setInputPage((pageNumber + 1).toString());
    }
  };

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setInputPage(e.target.value);
  };

  const handlePageJump = () => {
    const page = parseInt(inputPage, 10);
    if (numPages && page >= 1 && page <= numPages) {
      setPageNumber(page);
    } else {
      setInputPage(pageNumber.toString());
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center p-8">
        <div className="text-gray-600">Chargement du PDF...</div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="flex items-center justify-center p-8">
        <div className="text-red-600">{error}</div>
      </div>
    );
  }

  return (
    <div className="w-full max-w-4xl mx-auto">
      {/* PDF Display */}
      <div className="border rounded-lg overflow-hidden mb-4 bg-white">
        <Document
          file={pdfFile}
          onLoadSuccess={onDocumentLoadSuccess}
          onLoadError={onDocumentLoadError}
          loading="Chargement du PDF..."
          error="Erreur lors du chargement du PDF"
        >
          <Page
            pageNumber={pageNumber}
            renderTextLayer={false}
            renderAnnotationLayer={false}
            className="shadow-sm"
          />
        </Document>
      </div>

      {/* Navigation Controls */}
      <div className="flex items-center justify-center space-x-4 p-4 bg-gray-100 rounded-lg">
        <button
          onClick={handlePrevious}
          disabled={pageNumber <= 1}
          className="px-4 py-2 bg-blue-500 text-white rounded disabled:bg-gray-300 disabled:cursor-not-allowed hover:bg-blue-600"
        >
          Précédent
        </button>

        <div className="flex items-center space-x-2">
          <span className="text-sm">Page</span>
          <input
            type="number"
            min="1"
            max={numPages || 1}
            value={inputPage}
            onChange={handleInputChange}
            onKeyDown={(e) => {
              if (e.key === 'Enter') {
                handlePageJump();
              }
            }}
            className="w-16 px-2 py-1 border rounded text-center"
          />
          <span className="text-sm">sur {numPages}</span>
        </div>

        <button
          onClick={handleNext}
          disabled={!numPages || pageNumber >= numPages}
          className="px-4 py-2 bg-blue-500 text-white rounded disabled:bg-gray-300 disabled:cursor-not-allowed hover:bg-blue-600"
        >
          Suivant
        </button>
      </div>
    </div>
  );
};

export default PDFViewerControl;